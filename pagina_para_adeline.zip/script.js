const openBtn = document.getElementById("openBtn");
const inicio = document.getElementById("inicio");
const carta = document.getElementById("carta");
const music = document.getElementById("music");
const musicBtn = document.getElementById("musicBtn");
const musicText = document.getElementById("musicText");

openBtn.addEventListener("click", () => {
  inicio.classList.add("hide");

  setTimeout(() => {
    inicio.style.display = "none";
    carta.classList.remove("hidden");

    requestAnimationFrame(() => {
      carta.style.opacity = "1";
    });

    window.scrollTo({ top: 0, behavior: "smooth" });
  }, 650);
});

musicBtn.addEventListener("click", async () => {
  try {
    if (music.paused) {
      await music.play();
      musicBtn.classList.add("playing");
      musicText.textContent = "Reproduciendo";
    } else {
      music.pause();
      musicBtn.classList.remove("playing");
      musicText.textContent = "Música";
    }
  } catch (error) {
    musicText.textContent = "Agrega treat-you-better.mp3";
    setTimeout(() => musicText.textContent = "Música", 3000);
  }
});
