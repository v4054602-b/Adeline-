# Página para Adeline 💛

Esta es una página romántica/tierna de una sola página, preparada para verse bien en celular.

## Archivos
- `index.html` — contenido
- `style.css` — diseño y animaciones
- `script.js` — botones e interacción

## Música
Por derechos de autor no viene incluida la canción "Treat You Better" de Shawn Mendes.
Si tienes una copia de audio obtenida legalmente y puedes usarla, colócala en esta carpeta con exactamente este nombre:

`treat-you-better.mp3`

El botón "Música" la reproducirá.

## Publicarla
Puedes subir estos archivos a un servicio de hosting estático como GitHub Pages.
El archivo principal debe seguir llamándose `index.html`.

## Personalización rápida
En `index.html` puedes cambiar el texto de la carta directamente.
